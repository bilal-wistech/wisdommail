
var ApiGen = ApiGen || {};
ApiGen.elements = [["c","Acelle\\Http\\Controllers\\Api\\CampaignController"],["c","Acelle\\Http\\Controllers\\Api\\MailListController"],["c","Acelle\\Http\\Controllers\\Api\\SubscriberController"]];
